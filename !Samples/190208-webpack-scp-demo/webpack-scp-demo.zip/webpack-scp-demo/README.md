Follow my article on [Medium](https://medium.com/@thatisuday/react-router-and-webpack-v4-code-splitting-using-splitchunksplugin-f0a48f110312)
