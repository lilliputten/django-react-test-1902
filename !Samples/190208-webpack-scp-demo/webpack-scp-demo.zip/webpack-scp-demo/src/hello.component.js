// hello.component.js
import React from 'react';

const HelloComponent = ( props ) => {
    return (
        <span style={ { color: 'red' } }>Hello Component!</span>
    );
}

export default HelloComponent;